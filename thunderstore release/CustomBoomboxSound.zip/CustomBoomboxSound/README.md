# Custom Boombox Sound

This mod replaces the in-game boombox music with a custom royalty-free track:  
**"Susan - Royalty Free Instrumental Disco-House Music Loop (125 bpm)"**.

Place your `custom.ogg` in the plugin folder if you'd like to change the music.

---

## Credits
Music by [The Loop Lady](https://thelooplady.bandcamp.com/track/susan-royalty-free-instrumental-disco-house-music-loop-125-bpm) – used under royalty-free license.
