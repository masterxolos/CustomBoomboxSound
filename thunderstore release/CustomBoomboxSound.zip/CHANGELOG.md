# 1.0.0
- Initial release
- Boombox music replaced with custom sound
